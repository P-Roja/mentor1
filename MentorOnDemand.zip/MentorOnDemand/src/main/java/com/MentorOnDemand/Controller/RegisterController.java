package com.MentorOnDemand.Controller;

import java.sql.SQLException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.MentorOnDemand.model.Mentor;
import com.MentorOnDemand.model.User;

@Controller
public class RegisterController {
	@RequestMapping("/registerUser")
	public ModelAndView insertUser(ModelMap map) throws SQLException {
		ModelAndView mav = null;
		map.addAttribute("user", new User());
       map.addAttribute("mentor",new Mentor());
		mav = new ModelAndView("UserRegister");
		return mav;

	}
	@RequestMapping("/registerMentor")
	public ModelAndView insertMentor(ModelMap map) throws SQLException {
		ModelAndView mav = null;
       map.addAttribute("mentor",new Mentor());
		mav = new ModelAndView("MentorRegister");
		return mav;

	}

}
