package com.MentorOnDemand.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mentor_payment")
public class MentorPayment {

	@Column(name = "payment_id")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
	private long id;
	@Column(name = "mentor_mail")
	private String email;
	@Column(name = "course_name")
	private String courseName;
	@Column(name = "slot_1")
	private String slot1;
	@Column(name = "slot_2")
	private String slot2;
	@Column(name = "slot_3")
	private String slot3;
	@Column(name = "slot_4")
	private String slot4;
	@Column(name = "total_fee")
	private String totalFee;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getSlot1() {
		return slot1;
	}
	public void setSlot1(String slot1) {
		this.slot1 = slot1;
	}
	public String getSlot2() {
		return slot2;
	}
	public void setSlot2(String slot2) {
		this.slot2 = slot2;
	}
	public String getSlot3() {
		return slot3;
	}
	public void setSlot3(String slot3) {
		this.slot3 = slot3;
	}
	public String getSlot4() {
		return slot4;
	}
	public void setSlot4(String slot4) {
		this.slot4 = slot4;
	}
	public String getTotalFee() {
		return totalFee;
	}
	public void setTotalFee(String totalFee) {
		this.totalFee = totalFee;
	}
	public MentorPayment(String email, String courseName, String slot1, String slot2, String slot3, String slot4,
			String totalFee) {
		super();
		this.email = email;
		this.courseName = courseName;
		this.slot1 = slot1;
		this.slot2 = slot2;
		this.slot3 = slot3;
		this.slot4 = slot4;
		this.totalFee = totalFee;
	}
	public MentorPayment() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "MentorPayment [id=" + id + ", email=" + email + ", courseName=" + courseName + ", slot1=" + slot1
				+ ", slot2=" + slot2 + ", slot3=" + slot3 + ", slot4=" + slot4 + ", totalFee=" + totalFee + "]";
	}
	
	
}
