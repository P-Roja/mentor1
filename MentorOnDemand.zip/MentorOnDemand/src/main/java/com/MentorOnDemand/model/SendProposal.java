package com.MentorOnDemand.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="send_proposal")
public class SendProposal {

	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column
	private String CourseName;
	@Column
	private String mentorMail;
	@Column
	private String userMail;
	@Column
	private String  status;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCourseName() {
		return CourseName;
	}
	public void setCourseName(String courseName) {
		CourseName = courseName;
	}
	public String getMentorMail() {
		return mentorMail;
	}
	public void setMentorMail(String mentorMail) {
		this.mentorMail = mentorMail;
	}
	public String getUserMail() {
		return userMail;
	}
	public void setUserMail(String userMail) {
		this.userMail = userMail;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public SendProposal(String courseName, String mentorMail, String userMail, String status) {
		super();
		CourseName = courseName;
		this.mentorMail = mentorMail;
		this.userMail = userMail;
		this.status = status;
	}
	public SendProposal() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
