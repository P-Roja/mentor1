package com.MentorOnDemand.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_payment")
public class UserPayment {
	@Id
	@Column(name="payment_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long paymentId;
	@Column(name ="training_id")
	private long trainingId;
	@Column(name = "mentor_mail_id")
	private String mentorMailId;
	@Column(name ="course_name")
	private String courseName;
	@Column(name = "amount")
	private String amount;
	public long getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(long paymentId) {
		this.paymentId = paymentId;
	}
	public long getTrainingId() {
		return trainingId;
	}
	public void setTrainingId(long trainingId) {
		this.trainingId = trainingId;
	}
	public String getMentorMailId() {
		return mentorMailId;
	}
	public void setMentorMailId(String mentorMailId) {
		this.mentorMailId = mentorMailId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public UserPayment(long trainingId, String mentorMailId, String courseName, String amount) {
		super();
		this.trainingId = trainingId;
		this.mentorMailId = mentorMailId;
		this.courseName = courseName;
		this.amount = amount;
	}
	public UserPayment() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "UserPayment [paymentId=" + paymentId + ", trainingId=" + trainingId + ", mentorMailId=" + mentorMailId
				+ ", courseName=" + courseName + ", amount=" + amount + "]";
	}
	
	
	
	
}
