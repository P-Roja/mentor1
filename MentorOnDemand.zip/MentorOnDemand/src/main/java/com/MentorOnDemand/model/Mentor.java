package com.MentorOnDemand.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name= "mentor")
public class Mentor {
 
	
	@Id
	@Column(name="mentorId")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private long mentorId;
	@Column(name="name")
	 private String name;

	@Column(name="email")
	 private String email;
	
	@Column(name="password")
	 private String password;
	
	@Column(name="address")
	 private String address;
	
	@Column(name="linkedin_url")
	 private String linkedinUrl;
	
	 @Column(name="slot_time")
	 private String slotTime;
	 
	 @Column(name="technology")
	 private String technology;
	 
	 @Column(name="experience")
	 private String experience;
	 
	 @Column(name="contact_number")
	 private String contactNumber;
	 
	 @Column(name="reg_date_time")
     private String regDateTime;

	 @Column(name="status")
     private String status;

	public long getMentorId() {
		return mentorId;
	}

	public void setMentorId(long mentorId) {
		this.mentorId = mentorId;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLinkedinUrl() {
		return linkedinUrl;
	}

	public void setLinkedinUrl(String linkedinUrl) {
		this.linkedinUrl = linkedinUrl;
	}

	public String getSlotTime() {
		return slotTime;
	}

	public void setSlotTime(String slotTime) {
		this.slotTime = slotTime;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getRegDateTime() {
		return regDateTime;
	}

	public void setRegDateTime(String regDateTime) {
		this.regDateTime = regDateTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public Mentor() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Mentor(String name, String email, String password, String address, String linkedinUrl, String slotTime,
			String technology, String experience, String contactNumber, String regDateTime, String status) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.address = address;
		this.linkedinUrl = linkedinUrl;
		this.slotTime = slotTime;
		this.technology = technology;
		this.experience = experience;
		this.contactNumber = contactNumber;
		this.regDateTime = regDateTime;
		this.status = status;
	}
	 
	 
	 
	
	 
}
